from  package.folder1.SuB_folder import logger
#from __init__ import*
logger.warning('This is a warning fiooskdjsldf')
logger.error('This is an asdcsdcserror')
logger.debug('This is a debug message')
logger.info('This is an info message')
logger.warning('This is a warning message')
logger.error('This is an error message')
logger.critical('This is a critical message')
logger.debug('This is a debug message')
logger.info('This is an info message')
logger.warning('This is a warning message')
logger.error('This is an error message')
logger.critical('This is a critical message')
logger.debug('This is a debug message')
logger.info('This is an info message')
logger.warning('This is a warning message')
logger.error('This is an error message')
logger.critical('This is a critical message')
logger.debug('This is a debug message')
logger.info('This is an info message')
logger.warning('This is a warning message')
logger.error('This is an error message')
logger.critical('This is a critical message')
logger.debug('This is a debug message')
logger.info('This is an info message')
logger.warning('This is a warning message')
try:
    1/0
except:
    logger.error('This is an error message',exc_info=True)
    

logger.critical('This is a critical message')

